# NetBot

Full-stack AI chatbot: FastAPI + Supabase (Postgres/pgvector) backend, Next.js frontend.

## Structure
```
netbot/
├── backend/     -- FastAPI, Supabase, Gemini
└── frontend/    -- Next.js
```

## Backend setup
```bash
cd backend
cp .env.example .env      # fill in SUPABASE_URL, SUPABASE_KEY (service_role), GEMINI_API_KEY, JWT_SECRET_KEY
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```
Run `schema.sql` in the Supabase SQL editor, and create a private Storage bucket named `documents`.
ffmpeg must be installed on the host separately (required by Whisper, not pip-installable).

```bash
uvicorn app.main:app --reload
```
Swagger UI: http://localhost:8000/docs

## Frontend setup
```bash
cd frontend
npm install
npm run dev
```

## Features
- Email + face signup/login (JWT-based)
- Text chat with short-term (session) memory and vector-based long-term memory
- Document upload -> chunk -> embed -> RAG-grounded Q&A
- Tool calling (calculator, web search) inside chat
- Speech-to-text (Whisper) and text-to-speech (gTTS)
- Safety pipeline: topic guardrails + Gemini safety settings

## Known gaps / next steps
- `services/rag/reranker.py` is a pass-through stub -- no cross-encoder rerank yet
- `web_search` tool needs a `SEARCH_API_KEY` (serper.dev or similar) to function
- `tests/` cover pure logic (chunking, tools, safety, memory extraction, JWT); `test_chat.py`
  is a placeholder since a real integration test needs a mocked/local Supabase + Gemini client
- No CI pipeline yet
