from app.services.memory.long_term import extract_explicit_memory
from app.services.memory.retrieval import format_memory_context


def test_extract_explicit_memory_trigger():
    assert extract_explicit_memory("remember that I'm vegetarian") == "I'm vegetarian"
    assert extract_explicit_memory("Remember: my birthday is June 3") == "my birthday is June 3"


def test_extract_explicit_memory_no_trigger():
    assert extract_explicit_memory("what's the weather today") is None


def test_format_memory_context_empty():
    assert format_memory_context([]) is None


def test_format_memory_context_bullets():
    memories = [{"content": "vegetarian"}, {"content": "lives in Lahore"}]
    result = format_memory_context(memories)
    assert "- vegetarian" in result
    assert "- lives in Lahore" in result
