from app.services.security import hash_password, verify_password, create_access_token
from app.dependencies import get_current_user
from fastapi import HTTPException
import pytest


def test_password_hash_roundtrip():
    hashed = hash_password("correct horse battery staple")
    assert verify_password("correct horse battery staple", hashed)
    assert not verify_password("wrong password", hashed)


def test_jwt_roundtrip():
    token = create_access_token(user_id="user-123", email="a@b.com")
    result = get_current_user(authorization=f"Bearer {token}")
    assert result["user_id"] == "user-123"
    assert result["email"] == "a@b.com"


def test_missing_auth_header_rejected():
    with pytest.raises(HTTPException) as exc_info:
        get_current_user(authorization=None)
    assert exc_info.value.status_code == 401


def test_garbage_token_rejected():
    with pytest.raises(HTTPException) as exc_info:
        get_current_user(authorization="Bearer not-a-real-token")
    assert exc_info.value.status_code == 401
