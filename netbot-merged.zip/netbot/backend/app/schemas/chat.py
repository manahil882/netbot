from pydantic import BaseModel


class ChatRequest(BaseModel):
    session_id: str
    message: str
    use_memory: bool = True
    use_tools: bool = True


class ChatResponse(BaseModel):
    response: str
    tools_used: list[str] = []
