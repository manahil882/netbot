from pydantic import BaseModel, EmailStr


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str


class SignupResponse(TokenResponse):
    message: str = "User registered successfully"


class FaceLoginResponse(TokenResponse):
    similarity: float
