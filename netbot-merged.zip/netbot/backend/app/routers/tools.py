from fastapi import APIRouter, Depends, HTTPException

from app.services.tools.registry import execute_tool
from app.utils.exceptions import ToolExecutionError
from app.dependencies import get_current_user
from app.schemas.tools import ToolCallResult

router = APIRouter(prefix="/tools", tags=["Tools"])


@router.post("/{tool_name}/invoke", response_model=ToolCallResult)
async def invoke_tool(tool_name: str, arguments: dict, user=Depends(get_current_user)):
    """Manual tool invocation, separate from the automatic tool-calling that
    happens inside /chat -- useful for testing a tool or building a UI
    button that runs one directly."""
    try:
        result = execute_tool(tool_name, arguments)
    except ToolExecutionError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return ToolCallResult(tool=tool_name, arguments=arguments, result=result)
