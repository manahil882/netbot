from fastapi import APIRouter, HTTPException, Depends
from google.genai import types

from app.services.llm.gemini import client
from app.services.llm.prompts import build_chat_prompt
from app.services.memory.conversation import get_history, append_turn
from app.services.memory.retrieval import retrieve_relevant_memories, format_memory_context
from app.services.memory.long_term import extract_explicit_memory, save_memory
from app.services.tools.registry import get_gemini_tools, execute_tool
from app.services.safety import policy
from app.services.safety.moderation import DEFAULT_SAFETY_SETTINGS
from app.utils.exceptions import PolicyViolation
from app.dependencies import get_current_user
from app.schemas.chat import ChatRequest, ChatResponse

router = APIRouter(prefix="/chat", tags=["Chat"])

MODEL_NAME = "gemini-2.5-flash"
MAX_TOOL_ROUNDS = 3  # guards against a runaway tool-call loop


@router.post("/", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest, user=Depends(get_current_user)):
    try:
        policy.check_input(req.message)
    except PolicyViolation as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Explicit "remember that ..." messages get stored as long-term memory
    # immediately, in addition to being answered normally below.
    explicit_memory = extract_explicit_memory(req.message)
    if explicit_memory:
        save_memory(user["user_id"], explicit_memory)

    memory_context = None
    if req.use_memory:
        memories = retrieve_relevant_memories(user["user_id"], req.message)
        memory_context = format_memory_context(memories)

    history = get_history(req.session_id)
    contents = [
        types.Content(role=msg["role"], parts=[types.Part.from_text(text=msg["content"])])
        for msg in history
    ]
    prompt = build_chat_prompt(req.message, memory_context)
    contents.append(types.Content(role="user", parts=[types.Part.from_text(text=prompt)]))

    tools = get_gemini_tools() if req.use_tools else None
    tools_used: list[str] = []

    try:
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=contents,
            config=types.GenerateContentConfig(tools=tools, safety_settings=DEFAULT_SAFETY_SETTINGS)
            if tools
            else types.GenerateContentConfig(safety_settings=DEFAULT_SAFETY_SETTINGS),
        )

        # Function-calling loop: Gemini may request one or more tool calls
        # before producing a final text answer.
        rounds = 0
        while response.candidates and response.candidates[0].content.parts:
            function_calls = [
                part.function_call
                for part in response.candidates[0].content.parts
                if getattr(part, "function_call", None)
            ]
            if not function_calls or rounds >= MAX_TOOL_ROUNDS:
                break

            contents.append(response.candidates[0].content)
            function_response_parts = []
            for call in function_calls:
                tools_used.append(call.name)
                result = execute_tool(call.name, dict(call.args))
                function_response_parts.append(
                    types.Part.from_function_response(name=call.name, response={"result": result})
                )
            contents.append(types.Content(role="user", parts=function_response_parts))

            response = client.models.generate_content(
                model=MODEL_NAME,
                contents=contents,
                config=types.GenerateContentConfig(tools=tools, safety_settings=DEFAULT_SAFETY_SETTINGS),
            )
            rounds += 1

        policy.check_output(response)
        reply_text = response.text

    except PolicyViolation as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    append_turn(req.session_id, user["user_id"], req.message, reply_text)

    return ChatResponse(response=reply_text, tools_used=tools_used)
