from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends
from google.genai import types

from app.services.llm.gemini import client
from app.services.llm.prompts import RAG_ANSWER_PROMPT
from app.services.rag.ingestion import ingest_document
from app.services.rag.retriever import retrieve_chunks
from app.services.rag.reranker import rerank
from app.services.supabase import supabase
from app.utils.file_validation import validate_upload, FileValidationError
from app.utils.exceptions import DocumentProcessingError
from app.dependencies import get_current_user
from app.schemas.documents import UploadResponse, AskResponse, Source

router = APIRouter(prefix="/documents", tags=["Documents"])


@router.post("/upload", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...), user=Depends(get_current_user)):
    file_bytes = await file.read()

    try:
        validate_upload(file, file_bytes, kind="document")
    except FileValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        result = ingest_document(file_bytes, file.filename, file.content_type, user["user_id"])
    except DocumentProcessingError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return UploadResponse(**result)


@router.post("/{document_id}/ask", response_model=AskResponse)
async def ask_document(document_id: str, question: str = Form(...), user=Depends(get_current_user)):
    doc = (
        supabase.table("documents")
        .select("id")
        .eq("id", document_id)
        .eq("user_id", user["user_id"])
        .single()
        .execute()
    )
    if not doc.data:
        raise HTTPException(status_code=404, detail="Document not found")

    chunks = retrieve_chunks(document_id, user["user_id"], question)
    chunks = rerank(chunks, question)
    if not chunks:
        raise HTTPException(status_code=404, detail="No relevant content found in this document")

    context = "\n\n---\n\n".join(c["content"] for c in chunks)
    prompt = RAG_ANSWER_PROMPT.format(context=context, question=question)

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=[types.Content(role="user", parts=[types.Part.from_text(text=prompt)])],
    )

    return AskResponse(
        answer=response.text,
        sources=[Source(chunk_index=c["chunk_index"], similarity=c["similarity"]) for c in chunks],
    )


@router.get("/")
async def list_documents(user=Depends(get_current_user)):
    res = (
        supabase.table("documents")
        .select("id, filename, status, created_at")
        .eq("user_id", user["user_id"])
        .order("created_at", desc=True)
        .execute()
    )
    return res.data


@router.post("/explain")
async def upload_and_explain(
    file: UploadFile = File(...),
    prompt: str = Form("Explain this document in detail."),
    user=Depends(get_current_user),
):
    """Quick one-shot explanation -- doesn't touch the RAG index."""
    file_bytes = await file.read()
    part = types.Part.from_bytes(data=file_bytes, mime_type=file.content_type or "application/pdf")

    response = client.models.generate_content(model="gemini-2.5-flash", contents=[part, prompt])
    return {"filename": file.filename, "explanation": response.text}
