from fastapi import APIRouter, UploadFile, File, Form, HTTPException

from app.services.security import hash_password, verify_password, create_access_token
from app.services.face.enrollment import enroll_face_new_user
from app.services.face.verification import verify_face, FaceVerificationError
from app.services.face.recognition import FaceDetectionError
from app.services.supabase import supabase
from app.schemas.auth import SignupResponse, TokenResponse, FaceLoginResponse

router = APIRouter(prefix="/auth", tags=["Auth"])


def _fetch_profile_by_email(email: str):
    try:
        res = (
            supabase.table("profiles")
            .select("id, email, password_hash, face_embedding")
            .eq("email", email)
            .single()
            .execute()
        )
        return res.data
    except Exception:
        return None


@router.post("/signup", response_model=SignupResponse)
async def signup(
    email: str = Form(...),
    password: str = Form(...),
    face_image: UploadFile = File(...),
):
    if _fetch_profile_by_email(email):
        raise HTTPException(status_code=400, detail="Email already registered")

    try:
        user = enroll_face_new_user(email, hash_password(password), await face_image.read())
    except FaceDetectionError as e:
        raise HTTPException(status_code=400, detail=str(e))

    token = create_access_token(user_id=user["id"], email=email)
    return SignupResponse(access_token=token, user_id=user["id"])


@router.post("/login", response_model=TokenResponse)
async def login(email: str = Form(...), password: str = Form(...)):
    profile = _fetch_profile_by_email(email)
    if not profile or not verify_password(password, profile["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(user_id=profile["id"], email=profile["email"])
    return TokenResponse(access_token=token, user_id=profile["id"])


@router.post("/face-login", response_model=FaceLoginResponse)
async def face_login(email: str = Form(...), face_image: UploadFile = File(...)):
    try:
        match = verify_face(email, await face_image.read())
    except FaceVerificationError as e:
        raise HTTPException(status_code=401, detail=str(e))

    token = create_access_token(user_id=match["id"], email=match["email"])
    return FaceLoginResponse(access_token=token, user_id=match["id"], similarity=match["similarity"])
