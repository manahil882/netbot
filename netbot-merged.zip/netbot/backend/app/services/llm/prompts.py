SYSTEM_PERSONA = (
    "You are NetBot, a helpful assistant. Be concise and direct. "
    "If you use a tool, briefly mention what you used it for."
)

RAG_ANSWER_PROMPT = (
    "Answer the question using ONLY the context below. "
    "If the answer isn't in the context, say you don't know.\n\n"
    "Context:\n{context}\n\nQuestion: {question}"
)

MEMORY_CONTEXT_PREFIX = (
    "Relevant facts you remember about this user from earlier conversations "
    "(use only if relevant, don't force them into the reply):\n{memories}\n"
)


def build_chat_prompt(user_message: str, memory_context: str | None = None) -> str:
    """Wraps the user's raw message with recalled long-term memory, if any."""
    if not memory_context:
        return user_message
    return f"{MEMORY_CONTEXT_PREFIX.format(memories=memory_context)}\nUser message: {user_message}"
