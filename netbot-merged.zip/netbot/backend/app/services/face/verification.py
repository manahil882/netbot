import json

import numpy as np

from app.services.face.recognition import extract_embedding, FaceDetectionError
from app.services.supabase import supabase

FACE_MATCH_THRESHOLD = 0.70  # cosine similarity; tune against real enrollment data


class FaceVerificationError(Exception):
    pass


def verify_face(email: str, image_bytes: bytes) -> dict:
    """Returns the matched profile dict on success, raises FaceVerificationError otherwise."""
    try:
        profile_res = (
            supabase.table("profiles")
            .select("id, email, face_embedding")
            .eq("email", email)
            .single()
            .execute()
        )
        profile = profile_res.data
    except Exception:
        profile = None

    if not profile or not profile.get("face_embedding"):
        raise FaceVerificationError("No face profile found for this email")

    stored_embedding = np.array(json.loads(profile["face_embedding"]))

    try:
        live_embedding = np.array(extract_embedding(image_bytes))
    except FaceDetectionError as e:
        raise FaceVerificationError(str(e))

    similarity = float(
        np.dot(stored_embedding, live_embedding)
        / (np.linalg.norm(stored_embedding) * np.linalg.norm(live_embedding))
    )

    if similarity < FACE_MATCH_THRESHOLD:
        raise FaceVerificationError("Facial recognition verification failed")

    return {"id": profile["id"], "email": profile["email"], "similarity": similarity}
