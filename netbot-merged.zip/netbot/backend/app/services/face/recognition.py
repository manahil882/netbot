import numpy as np
import cv2
from deepface import DeepFace

from app.utils.exceptions import NetBotError


class FaceDetectionError(NetBotError):
    pass


def extract_embedding(image_bytes: bytes) -> list[float]:
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        raise FaceDetectionError("Could not decode face image")

    try:
        result = DeepFace.represent(img_path=img, model_name="Facenet")
    except ValueError as e:
        # DeepFace raises ValueError when it can't find a face in the image
        raise FaceDetectionError(f"No face detected: {e}")

    return result[0]["embedding"]
