from app.services.supabase import supabase
from app.services.rag.embeddings import embed_text

# Heuristic trigger for now -- a real system would run a periodic LLM pass
# over conversations to extract facts worth remembering. This is the
# simplest thing that's actually functional end to end.
REMEMBER_TRIGGERS = ("remember that ", "remember: ", "please remember ")


def extract_explicit_memory(user_message: str) -> str | None:
    lowered = user_message.lower()
    for trigger in REMEMBER_TRIGGERS:
        if lowered.startswith(trigger):
            return user_message[len(trigger):].strip()
    return None


def save_memory(user_id: str, content: str) -> dict:
    embedding = embed_text(content)
    res = (
        supabase.table("long_term_memories")
        .insert({"user_id": user_id, "content": content, "embedding": embedding})
        .execute()
    )
    return res.data[0] if res.data else {}


def list_memories(user_id: str) -> list[dict]:
    res = (
        supabase.table("long_term_memories")
        .select("id, content, created_at")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .execute()
    )
    return res.data or []


def delete_memory(user_id: str, memory_id: str) -> None:
    supabase.table("long_term_memories").delete().eq("id", memory_id).eq("user_id", user_id).execute()
