from app.services.supabase import supabase


def get_history(session_id: str) -> list[dict]:
    res = (
        supabase.table("chat_history")
        .select("role, content")
        .eq("session_id", session_id)
        .order("created_at")
        .execute()
    )
    return res.data or []


def append_turn(session_id: str, user_id: str, user_message: str, model_reply: str) -> None:
    supabase.table("chat_history").insert(
        [
            {"session_id": session_id, "user_id": user_id, "role": "user", "content": user_message},
            {"session_id": session_id, "user_id": user_id, "role": "model", "content": model_reply},
        ]
    ).execute()
