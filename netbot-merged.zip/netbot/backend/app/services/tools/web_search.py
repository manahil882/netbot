import requests

from app.config import settings
from app.utils.exceptions import ToolExecutionError

# Written against Serper.dev's API shape (cheap, simple JSON-in/JSON-out
# Google search wrapper). Swap the URL/parsing if you use a different
# provider (Tavily, Bing, Brave Search API, etc.) -- the calling contract
# (query in, list[{"title","link","snippet"}] out) stays the same.
SERPER_URL = "https://google.serper.dev/search"


def web_search(query: str, num_results: int = 5) -> list[dict]:
    api_key = getattr(settings, "SEARCH_API_KEY", None)
    if not api_key:
        raise ToolExecutionError(
            "No SEARCH_API_KEY configured -- sign up for a search API (e.g. serper.dev) "
            "and set SEARCH_API_KEY in .env to enable this tool."
        )

    try:
        response = requests.post(
            SERPER_URL,
            headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
            json={"q": query, "num": num_results},
            timeout=10,
        )
        response.raise_for_status()
    except requests.RequestException as e:
        raise ToolExecutionError(f"Web search request failed: {e}")

    data = response.json()
    return [
        {"title": r.get("title"), "link": r.get("link"), "snippet": r.get("snippet")}
        for r in data.get("organic", [])[:num_results]
    ]
