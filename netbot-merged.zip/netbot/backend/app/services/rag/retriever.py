from app.services.supabase import supabase
from app.services.rag.embeddings import embed_text


def retrieve_chunks(document_id: str, user_id: str, question: str, top_k: int = 5) -> list[dict]:
    query_embedding = embed_text(question)

    matches = supabase.rpc(
        "match_document_chunks",
        {
            "query_embedding": query_embedding,
            "match_document_id": document_id,
            "match_user_id": user_id,
            "match_count": top_k,
        },
    ).execute()

    return matches.data or []
