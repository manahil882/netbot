"""Placeholder. retriever.py's pgvector search is a single-stage retrieval --
good enough for small-to-medium documents. If answer quality on large or
noisy documents needs work, this is where a cross-encoder rerank pass
(e.g. a local sentence-transformers CrossEncoder, or Cohere Rerank) would
slot in: take retriever.py's top ~20 candidates, rerank, return the top 5.
Not implemented yet -- deliberately left as a pass-through rather than a
fake reranking implementation."""

def rerank(chunks: list[dict], query: str) -> list[dict]:
    return chunks
