"""A cheap, fast pre-filter that runs BEFORE the LLM call. It's deliberately
simple -- broad topic categories with a handful of representative keywords
each, not an exhaustive blocklist. It's a first line of defense, not a
replacement for Gemini's own safety settings (see moderation.py) or a real
moderation model."""

BLOCKED_TOPICS: dict[str, list[str]] = {
    "weapons_synthesis": ["how to build a bomb", "synthesize explosive", "make a weapon"],
    "malware": ["write ransomware", "write a virus", "malware that spreads"],
    "self_harm_instructions": ["how to end my life", "how to hurt myself"],
}


def find_blocked_topic(text: str) -> str | None:
    """Returns the topic key if the text matches a blocked pattern, else None."""
    lowered = text.lower()
    for topic, phrases in BLOCKED_TOPICS.items():
        if any(phrase in lowered for phrase in phrases):
            return topic
    return None
