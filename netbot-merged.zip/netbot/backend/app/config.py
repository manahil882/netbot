from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    SUPABASE_URL: str
    SUPABASE_KEY: str  # service_role key -- backend bypasses RLS by design
    GEMINI_API_KEY: str

    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24

    # Optional -- web_search tool is disabled with a clear error if unset
    SEARCH_API_KEY: str | None = None

    class Config:
        env_file = ".env"


settings = Settings()
