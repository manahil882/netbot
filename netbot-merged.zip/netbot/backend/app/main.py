from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import auth, chat, docs, audio, memory, tools
from app.utils.logging import configure_logging

configure_logging()

app = FastAPI(title="NetBot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(chat.router)
app.include_router(docs.router)
app.include_router(audio.router)
app.include_router(memory.router)
app.include_router(tools.router)


@app.get("/")
def home():
    return {"message": "NetBot backend running"}
